module org.example.demo3 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.rmi;
    requires jdk.jfr;
    requires javafx.graphics;


    opens org.example.demo3 to javafx.fxml;
    exports org.example.demo3;
}