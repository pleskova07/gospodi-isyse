package org.example.demo3;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class HelloController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button enter;

    @FXML
    private TextField login;

    @FXML
    private PasswordField password;

    DBConnector dbConnector= new DBConnector();

    @FXML
    void OnActionEnter(ActionEvent event) throws IOException {
        if(dbConnector.TableConn(login.getText().trim(),password.getText().trim())){
            Stage stage = (Stage) enter.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("main.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            stage.setTitle("Главная!");
            stage.setScene(scene);
            stage.show();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка авторизации");
            alert.setHeaderText("Неверный логин или пароль.");
            alert.setContentText("Пожалуйста, проверьте введенные данные.\nХотите попробовать зарегистрироваться?");
            ButtonType registerButton = new ButtonType("Зарегистрироваться");
            ButtonType cancelButton = new ButtonType("Отмена", ButtonBar.ButtonData.CANCEL_CLOSE);
            alert.getButtonTypes().setAll(registerButton, cancelButton);
            Optional<ButtonType> result = alert.showAndWait();
            if(result.isPresent()&& result.get() == registerButton){
                Stage stage = (Stage) enter.getScene().getWindow();
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("registration.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 600, 400);
                stage.setTitle("Регистрация!");
                stage.setScene(scene);
                stage.show();
            }
        }
    }

    @FXML
    void initialize() {
        dbConnector.DBCoon();
        assert enter != null : "fx:id=\"enter\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert login != null : "fx:id=\"login\" was not injected: check your FXML file 'hello-view.fxml'.";
        assert password != null : "fx:id=\"password\" was not injected: check your FXML file 'hello-view.fxml'.";

    }

}
