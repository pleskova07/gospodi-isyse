package org.example.demo3;

import java.sql.*;

public class DBConnector {

    private String Url = "jdbc:mysql://localhost:3306/users";
    private String Username = "root";
    private String Password = "12345";

    public void DBCoon(){
        try(Connection connection = DriverManager.getConnection(Url, Username, Password)) {
            if (connection !=null){
                System.out.println("Подключенно к БД");
            }
        } catch (SQLException e) {
            System.out.println("Не подключился к БД");
            e.printStackTrace();
        }
    }

    public boolean TableConn(String login, String password) {
        try (Connection connection = DriverManager.getConnection(Url, Username, Password)) {
            PreparedStatement stat = connection.prepareStatement("SELECT * FROM user WHERE login = ? AND password = ?");
            stat.setString(1, login);
            stat.setString(2, password);
            ResultSet rs = stat.executeQuery();
            if (rs.next()){
                return true;
            } else {
                return false;
            }
        } catch (Exception ex){
            ex.printStackTrace();
            return false;
        }
    }

    public boolean RegUser(String Login, String password, String gender, String Name, String lastName) {
        try (Connection connection = DriverManager.getConnection(Url, Username, Password)) {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO user (Login, Password, gender, Name, LastName) " +
                    "VALUES (?, ?, ?, ?, ?) ");
            stmt.setString(1, Login);
            stmt.setString(2, password);
            stmt.setString(3, gender);
            stmt.setString(4, Name);
            stmt.setString(5, lastName);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0){
                return true;
            } else {
                return false;
            }
        } catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }
}
