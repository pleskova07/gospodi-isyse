package org.example.demo3;

import java.io.IOException;
import java.net.URL;
import java.rmi.registry.Registry;
import java.util.ResourceBundle;
import java.util.jar.Attributes;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import jdk.jfr.Registered;

public class Registration {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button cancellation;

    @FXML
    private CheckBox female;

    @FXML
    private TextField lastname;

    @FXML
    private TextField login;

    @FXML
    private CheckBox man;

    @FXML
    private TextField name;

    @FXML
    private PasswordField password;

    @FXML
    private Button register;

    private String Gender;
    DBConnector dbConnector = new DBConnector();

    @FXML
    void OnActionFemale(MouseEvent event) {
        female.setText("Женский");
        Gender=female.getText();
        System.out.println(female.getText());
    }

    @FXML
    void OnActionMale(MouseEvent event) {
        man.setText("Мужской");
        Gender=man.getText();
        System.out.println(man.getText());
    }

    @FXML
    void OnActionRegister(ActionEvent event) throws IOException {
        if (dbConnector.RegUser(login.getText(),password.getText(),Gender, name.getText(), lastname.getText())
                &&login.getText()!="?"
                &&password.getText()!="?"
                &&Gender!=""
                &&name.getText()!="?"
                &&lastname.getText()!="?"){
            Stage stage = (Stage) register.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            stage.setTitle("Hello!");
            stage.setScene(scene);
            stage.show();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Ошибка");
            alert.setContentText("Вы ввели неверные данные");
            alert.showAndWait();
        }

    }

    @FXML
    void OnActionСancellation(ActionEvent event) throws IOException {
        Stage stage = (Stage) cancellation.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        stage.setTitle("Главная!");
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void OnMauseOtmena(MouseEvent event) {

    }

    @FXML
    void OnMauseReg(MouseEvent event) {

    }

    @FXML
    void initialize() {
        assert cancellation != null : "fx:id=\"cancellation\" was not injected: check your FXML file 'registration.fxml'.";
        assert female != null : "fx:id=\"female\" was not injected: check your FXML file 'registration.fxml'.";
        assert lastname != null : "fx:id=\"lastname\" was not injected: check your FXML file 'registration.fxml'.";
        assert login != null : "fx:id=\"login\" was not injected: check your FXML file 'registration.fxml'.";
        assert man != null : "fx:id=\"male\" was not injected: check your FXML file 'registration.fxml'.";
        assert name != null : "fx:id=\"name\" was not injected: check your FXML file 'registration.fxml'.";
        assert password != null : "fx:id=\"password\" was not injected: check your FXML file 'registration.fxml'.";
        assert register != null : "fx:id=\"register\" was not injected: check your FXML file 'registration.fxml'.";

    }

}
